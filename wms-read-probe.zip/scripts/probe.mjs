import fs from "node:fs";
const masked = (v) => (v ? `${String(v).slice(0, 10)}...len=${String(v).length}` : "<unset>");
for (const n of ["WMS_BASE_URL", "AUTH_TOKEN", "IAM_TOKEN", "TENANT_ID", "FACILITY_ID", "COMPANY_ID", "USER_ID", "MODEL"]) {
  console.log(`ENV ${n}: ${masked(process.env[n])}`);
}
const base = process.env.WMS_BASE_URL || "https://unis.item.com/api";
const tokens = ["AUTH_TOKEN", "IAM_TOKEN"];
const targets = [
  ["exc", `${base}/wms/exception-line/search`, { tenantId: "LT", status: "PENDING", currentPage: 1, pageSize: 5 }],
  ["ord", `${base}/wms-bam/outbound/order/search`, { ids: ["DN-1"], currentPage: 1, pageSize: 5 }],
];
for (const t of tokens) {
  const tok = process.env[t];
  if (!tok) continue;
  for (const [label, url, body] of targets) {
    try {
      const r = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${tok}`,
          "x-tenant-id": process.env.TENANT_ID || "LT",
          "x-facility-id": process.env.FACILITY_ID || "LT_ORG-61213",
          "item-time-zone": "America/Chicago",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });
      const text = await r.text();
      console.log(`RESULT ${t} ${label}: HTTP ${r.status} :: ${text.slice(0, 220)}`);
      if (r.ok && label === "exc") {
        try {
          fs.writeFileSync("/home/user/workspace/.wms-token", tok, "utf8");
          fs.chmodSync("/home/user/workspace/.wms-token", 0o600);
          console.log("WROTE /home/user/workspace/.wms-token (mode 600)");
        } catch (e) {
          console.log("write token failed:", e.message);
        }
      }
    } catch (e) {
      console.log(`RESULT ${t} ${label}: ERR ${e.message}`);
    }
  }
}
