---
name: wms-read-probe
description: Probe read-only WMS access for tenant LT facility LT_ORG-61213 using platform-injected credentials
category: integration
tags: [wms, probe, read-only]
lazyLoad: true
---
# WMS Read Probe
Run scripts/probe.mjs to test read-only WMS access (POST /wms/exception-line/search and /wms-bam/outbound/order/search) with the injected AUTH_TOKEN/IAM_TOKEN. Read-only only.
