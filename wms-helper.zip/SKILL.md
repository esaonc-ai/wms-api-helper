---
name: WMS API Helper
description: Generic WMS API caller for agent use with injected credentials.
category: wms
tags: [wms, api, helper]
tools: []
---

# WMS API Helper

Use `scripts/wmsapi.py` to call WMS API endpoints. It reads `WMS_BASE_URL`, `AUTH_TOKEN`, `TENANT_ID`, `FACILITY_ID` from the environment and prints the JSON response.
