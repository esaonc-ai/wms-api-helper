#!/usr/bin/env python3
"""Generic WMS API caller. Usage: wmsapi.py <METHOD> <path> [json_body] [facility_id]
Reads WMS_BASE_URL (fallback https://wms-staging.item.com/api), AUTH_TOKEN, TENANT_ID, FACILITY_ID from env.
Prints status and response JSON (truncated to 200KB).
"""
import json, os, sys, urllib.request, urllib.error

BASE = os.environ.get("WMS_BASE_URL") or "https://wms-staging.item.com/api"
TOKEN = os.environ.get("AUTH_TOKEN") or os.environ.get("IAM_TOKEN") or ""
TENANT = os.environ.get("TENANT_ID") or ""
FACILITY = os.environ.get("FACILITY_ID") or ""

def main():
    args = sys.argv[1:]
    if len(args) < 2:
        print("usage: wmsapi.py METHOD PATH [json_body] [facility_id]")
        sys.exit(2)
    method = args[0].upper()
    path = args[1]
    body = args[2] if len(args) > 2 else None
    fac = args[3] if len(args) > 3 else FACILITY
    url = BASE.rstrip("/") + "/" + path.lstrip("/")
    data = body.encode() if body else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    req.add_header("x-request-client", "itemgpt")
    if TOKEN:
        auth = TOKEN if TOKEN.startswith("Bearer") else "Bearer " + TOKEN
        req.add_header("Authorization", auth)
    if TENANT:
        req.add_header("x-tenant-id", TENANT)
    if fac:
        req.add_header("x-facility-id", fac)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            raw = r.read()
            print("STATUS", r.status)
            print(raw[:200000].decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        print("STATUS", e.code)
        print(e.read()[:200000].decode("utf-8", "replace"))
    except Exception as e:
        print("ERROR", repr(e))

if __name__ == "__main__":
    main()
